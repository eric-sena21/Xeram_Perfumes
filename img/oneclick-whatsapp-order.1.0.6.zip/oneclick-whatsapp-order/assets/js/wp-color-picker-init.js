jQuery(document).ready(function($){
    /* Call the Color Picker */
    $( ".color-picker" ).wpColorPicker();
});